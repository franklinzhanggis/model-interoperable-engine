"""The Basic Model Interface."""
from .bmi import Bmi


__all__ = ['Bmi']
